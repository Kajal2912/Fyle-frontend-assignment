import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';
import { Workout } from '../../models/workout.model';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-workout-table',
  templateUrl: './workout-table.component.html',
  styleUrls: ['./workout-table.component.css']
})
export class WorkoutTableComponent implements OnInit {
  displayedColumns: string[] = ['type', 'duration', 'userName'];
  dataSource = new MatTableDataSource<Workout>();

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.dataService.workouts$.subscribe(workouts => {
      this.dataSource.data = workouts;
    });
  }
}
