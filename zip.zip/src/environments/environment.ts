// src/environments/environment.ts
export const environment = {
    production: false
  };
  