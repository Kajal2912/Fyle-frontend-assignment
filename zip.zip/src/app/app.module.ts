import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { FlexLayoutModule } from '@angular/flex-layout';
import { RouterModule } from '@angular/router';


import { AppComponent } from './app.component';
import { UserFormComponent } from './components/user-form/user-form.component';
import { WorkoutFormComponent } from './components/workout-form/workout-form.component';
import { WorkoutTableComponent } from './components/workout-table/workout-table.component';
import { SearchFilterComponent } from './components/search-filter/search-filter.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { WorkoutChartComponent } from './components/workout-chart/workout-chart.component';
import { DataService } from './services/data.service';
import { appRoutes } from './app.routes';

@NgModule({
  declarations: [
    AppComponent,
    UserFormComponent,
    WorkoutFormComponent,
    WorkoutTableComponent,
    SearchFilterComponent,
    PaginationComponent,
    WorkoutChartComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatCardModule,
    MatSelectModule,
    FlexLayoutModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
